<template>
    <div class="text-center">
        <img src="https://www.owniqs.co/wp-content/uploads/2021/08/All-Logo-stores-1536x123.jpg" alt="">
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>

</style>