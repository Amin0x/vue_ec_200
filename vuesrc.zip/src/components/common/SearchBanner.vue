<template>
    <div>

    </div>
</template>

<script>
    export default {
        name:'SearchBanner',
    }
</script>

<style scoped>

</style>