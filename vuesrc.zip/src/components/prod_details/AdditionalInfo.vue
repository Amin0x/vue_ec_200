<template>
  <div class="aa-section-additional_information card">
    <div class="header d-flex bg-light p-2">
            <div>
                <b-icon icon="list" style="color: #e65100;"></b-icon>
              <strong class="ms-2">Additional Information</strong>
            </div>
            <div class="ms-auto"><a href="" class="text-decoration-none text-reset">
                <b-icon icon="chevron-down"></b-icon>
            </a></div>
    </div>
    <div class="body px-3 py-2">Additional information</div>
  </div>
</template>

<script>
export default {
    data: function() {
      return {};
    }
};
</script>

<style lang="scss" scoped>
</style>