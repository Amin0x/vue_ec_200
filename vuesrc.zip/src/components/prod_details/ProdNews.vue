<template>
    <div class="aa-section-news card">
          <div class="header d-flex bg-light p-2">
            <div>
                <b-icon icon="list" style="color: #e65100;"></b-icon>
              <strong class="ms-2">News</strong>
            </div>
            <div class="ms-auto"><a href="" class="text-decoration-none text-reset">
                <b-icon icon="chevron-down"></b-icon>
            </a></div>
          </div>
        <div class="px-3 py-2">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi, beatae.
          Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem, magni.
          Lorem ipsum dolor sit amet consectetur.
        </div>
    </div>
</template>

<script>
export default {
    data: function(){
      return {};
    }
}
</script>

<style lang="scss" scoped>

</style>