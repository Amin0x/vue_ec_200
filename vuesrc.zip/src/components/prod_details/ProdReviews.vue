<template>
  <div class="aa-section-reviews card">
    <div class="header d-flex bg-light p-2">
            <div>
                <b-icon icon="list" style="color: #e65100;"></b-icon>
              <strong class="ms-2">
                  User Reviews (0)
              </strong>
            </div>
            <div class="ms-auto"><a href="" class="text-decoration-none text-reset">
                <b-icon icon="chevron-down"></b-icon>
            </a></div>
          </div>
    <div>
    <div class="body px-3 py-2">
        <div class="h4"><b-icon-star-fill></b-icon-star-fill> Reviews</div>
        <hr>
        <div class="d-flex justify-content-between align-items-center">
          <div class="me-3">
            <span style="font-size: 2rem; color: #ccc;">0.0</span> out of 5
          </div>
          <div class="aa-rate flex-grow-1 me-3">
            <div class="d-flex align-items-center">
              <div class="me-3">
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
              </div>
              <div class="me-3 flex-grow-1" style="height: 14px; background-color: #ccc;">
                <div style="height: 100%; width: 50%; background-color: #ff8a00;"></div>
              </div>
              <div>5</div>
            </div>
            <div class="d-flex">
              <div>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
              </div>
              <div></div>
              <div>5</div>
            </div>
            <div class="d-flex">
              <div>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
              </div>
              <div></div>
              <div>5</div>
            </div>
        
            <div class="d-flex">
              <div>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
              </div>
              <div></div>
              <div>5</div>
            </div>
            <div class="d-flex">
              <div>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
                <b-icon icon="star-fill"></b-icon>
              </div>
              <div></div>
              <div>5</div>
            </div>
          </div>
          <div>
            <a href="#" class="btn btn-danger">Lorem, ipsum dolor.</a>
          </div>
        </div>
            </div>
      </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>