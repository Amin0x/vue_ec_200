<template>
    <div class="aa-section-videos card">
         <div class="header d-flex bg-light p-2">
            <div>
                <b-icon icon="list" style="color: #e65100;"></b-icon>
              <strong class="ms-2">Videos</strong>
            </div>
            <div class="ms-auto"><a href="" class="text-decoration-none text-reset">
                <b-icon icon="chevron-down"></b-icon>
            </a></div>
          </div>
        <div class="body px-3 py-2">
          <div class="row">
            <div class="col-md-3 col-sm-6">
              
            </div>
          </div>
        </div>
      </div>
</template>

<script>
export default {
    name: "ProdVideos",
    data: function(){
      return {};
    },
}
</script>

<style lang="scss" scoped>

</style>