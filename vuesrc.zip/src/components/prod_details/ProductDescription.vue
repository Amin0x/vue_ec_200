<template>
  <div class="aa-section-description card">
    <div class="header d-flex bg-light p-2">
        <div>
            <b-icon icon="list" style="color: #e65100;"></b-icon>
            <strong class="ms-2">Description</strong>
        </div>
        <div class="ms-auto">
            <a href="" class="text-decoration-none text-reset"><b-icon icon="chevron-down"></b-icon></a>
        </div>
    </div>
    
    <div class="px-3 py-2">
      <p>Apple iPhone 12, 5G, 64GB, Black</p>
      <p>آبل أيفون 12 ميني ، 5 جي ، 64 جيجا ، أخضر</p>
      <p>Apple iPhone 12 MINI, 5G, 64GB, Green</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "ProductDesscription",
  data: function() {
    return {};
  },
};
</script>

<style lang="scss" scoped>
</style>