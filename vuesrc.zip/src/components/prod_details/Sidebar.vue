<template>
    <div class="sidebar">
        
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>