<template>
    <div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-2 col-lg-3">
                    <div class="item">
                        <div class="img">
                            <img src="" alt="">
                        </div>
                        <p class="title">
                            Lorem ipsum dolor sit amet.
                        </p>
                        <p class="desc">
                            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Expedita culpa 
                            Lorem ipsum dolor sit.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    name: "Search",
    data: function(){
        return {

        }
    },
}
</script>

<style lang="scss" scoped>

</style>