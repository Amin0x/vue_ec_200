<template>
    <top-navbar></top-navbar>
</template>

<script>
import TopNavbar from '../components/common/TopNavbar.vue'
export default {
  components: { TopNavbar },
    
}
</script>

<style lang="scss" scoped>

</style>